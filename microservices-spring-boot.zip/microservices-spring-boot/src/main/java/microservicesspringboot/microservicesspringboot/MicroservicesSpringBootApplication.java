package microservicesspringboot.microservicesspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicesSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicesSpringBootApplication.class, args);
	}

}
