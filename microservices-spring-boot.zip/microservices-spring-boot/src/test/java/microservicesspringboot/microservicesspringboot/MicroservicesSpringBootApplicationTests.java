package microservicesspringboot.microservicesspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicesSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
